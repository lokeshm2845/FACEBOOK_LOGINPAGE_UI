package com.example.fb_ui

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.util.Calendar

class SignUpActivity : AppCompatActivity() {

    private lateinit var btnBack: Button
    private lateinit var etFirstName: EditText
    private lateinit var etSurname: EditText
    private lateinit var etMobile: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etBirthday: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var btnSignUp: Button
    private lateinit var tvLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        etFirstName = findViewById(R.id.etFirstName)
        etSurname = findViewById(R.id.etSurname)
        etMobile = findViewById(R.id.etMobile)
        etNewPassword = findViewById(R.id.etNewPassword)
        etBirthday = findViewById(R.id.etBirthday)
        rgGender = findViewById(R.id.rgGender)
        btnSignUp = findViewById(R.id.btnSignUp)
        tvLogin = findViewById(R.id.tvLogin)
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnSignUp.setOnClickListener {
            attemptSignUp()
        }

        tvLogin.setOnClickListener {
            finish()
        }

        etBirthday.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun attemptSignUp() {
        val firstName = etFirstName.text.toString().trim()
        val surname = etSurname.text.toString().trim()
        val mobile = etMobile.text.toString().trim()
        val password = etNewPassword.text.toString().trim()
        val birthday = etBirthday.text.toString().trim()

        if (firstName.isEmpty()) {
            etFirstName.error = "Please enter first name"
            return
        }

        if (surname.isEmpty()) {
            etSurname.error = "Please enter surname"
            return
        }

        if (mobile.isEmpty()) {
            etMobile.error = "Please enter mobile number"
            return
        }

        if (password.isEmpty()) {
            etNewPassword.error = "Please enter password"
            return
        }

        if (password.length < 6) {
            etNewPassword.error = "Password must be at least 6 characters"
            return
        }

        if (birthday.isEmpty()) {
            etBirthday.error = "Please enter birthday"
            return
        }

        if (rgGender.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Please select gender", Toast.LENGTH_SHORT).show()
            return
        }

        val gender = getSelectedGender()
        Toast.makeText(this, "Account created successfully!\nGender: $gender", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate = String.format("%02d/%02d/%d", selectedDay, selectedMonth + 1, selectedYear)
                etBirthday.setText(formattedDate)
            },
            year,
            month,
            day
        )

        datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    private fun getSelectedGender(): String {
        return when (rgGender.checkedRadioButtonId) {
            R.id.rbFemale -> "Female"
            R.id.rbMale -> "Male"
            R.id.rbCustom -> "Custom"
            else -> ""
        }
    }
}